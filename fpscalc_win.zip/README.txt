These are the files needed to run the program fpscalc under a 
Windows (95, 98 or NT) environment.

Files:

fpscalc.exe       -- the executable program

ex_holistic.fps   -- example scenario
fpscalc.pdf       -- documentation
README.txt        -- this file

Run fpscalc by:

1. Start a MS-DOS-prompt
2. Go to where the program is located in your file hierarchy 
   in the DOS prompt (using cd)
3. Run the program on a scenario (eg. ex_holistic.fps) by typing:
     fpscalc < ex_holistic.fps      (normal printout)
     fpscalc -v < ex_holistic.fps   (extended printout) 
4. You can print the result to a file (eg. result.txt) by typing:
     fpscalc < ex_holistic.fps > result.txt

For more information on how to write scenarios etc. see the 
documentation file.

Andreas Ermedahl
ebbe@docs.uu.se
